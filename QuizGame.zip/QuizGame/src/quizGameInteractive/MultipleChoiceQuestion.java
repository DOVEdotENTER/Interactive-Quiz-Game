package quizGameInteractive;

import java.util.ArrayList;

public class MultipleChoiceQuestion extends Question{
	
	private ArrayList<String> options;
	private int correctOptionIndex;
	
	public MultipleChoiceQuestion(String question, ArrayList<String> options, 
			int correctOptionIndex) {
		super(question, options.get(correctOptionIndex));
		this.options = options;
		this.correctOptionIndex = correctOptionIndex;
	}
	
	@Override
	public boolean checkAnswer(String userAnswer) {
		
		try {
            int choice = Integer.parseInt(userAnswer);
            return choice == correctOptionIndex + 1;
        } catch (Exception e) {
            return false;
        }
    }

    public void printOptions() {
        for (int i = 0; i < options.size(); i++)
            System.out.println((i + 1) + ". " + options.get(i));
    }
 

}
