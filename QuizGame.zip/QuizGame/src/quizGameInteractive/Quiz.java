package quizGameInteractive;

import java.util.ArrayList;
import java.util.Scanner;


public class Quiz {
	
	private ArrayList<Question> questions = new ArrayList<>();

    public void addQuestion(Question q) {
    	questions.add(q); 
    	
    }

    public void start() {
    	
        Scanner sc = new Scanner(System.in);
        int score = 0;
        
        for (Question q : questions) {
        	
            System.out.println("\nQ: " + q.getQuestion());
            
            if (q instanceof MultipleChoiceQuestion) {
            	
            	((MultipleChoiceQuestion) q).printOptions();
            }
            
            System.out.print("Your answer: ");
            
            String userAnswer = sc.nextLine();
            
            if (q.checkAnswer(userAnswer)) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect! Correct answer: " + q.getAnswer());
            }
        }
        System.out.println("\nQuiz finished! Your score: " + score + "/" + questions.size());
    }

}
