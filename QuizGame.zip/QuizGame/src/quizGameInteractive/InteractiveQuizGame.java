package quizGameInteractive;

import java.util.ArrayList;
import java.util.Scanner;

public class InteractiveQuizGame {
	
	public static void main(String[] args) {
		
        Scanner sc = new Scanner(System.in);
        Quiz quiz = new Quiz();

        boolean running = true;

        while (running) {
            System.out.println("\n--- Quiz Menu ---");
            System.out.println("1. Add Basic Question");
            System.out.println("2. Add Multiple Choice Question");
            System.out.println("3. Start Quiz");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            String choice = sc.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Question: ");
                    String qText = sc.nextLine();
                    System.out.print("Answer: ");
                    String qAnswer = sc.nextLine();
                    quiz.addQuestion(new BasicQuestion(qText, qAnswer));
                    break;

                case "2":
                    System.out.print("Question: ");
                    String mQuestion = sc.nextLine();
                    ArrayList<String> options = new ArrayList<>();
                    for (int i = 1; i <= 4; i++) {
                        System.out.print("Option " + i + ": ");
                        options.add(sc.nextLine());
                    }
                    System.out.print("Correct option (1-4): ");
                    int correct = Integer.parseInt(sc.nextLine()) - 1;
                    quiz.addQuestion(new MultipleChoiceQuestion(mQuestion, options, correct));
                    break;

                case "3":
                    quiz.start();
                    break;

                case "0":
                    running = false;
                    System.out.println("Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }

        sc.close();
    }

}
