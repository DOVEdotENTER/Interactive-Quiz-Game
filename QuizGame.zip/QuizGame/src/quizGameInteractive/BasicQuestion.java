package quizGameInteractive;

public class BasicQuestion extends Question {
	
	public BasicQuestion(String question, String answer) {
		super(question, answer);
	}
	
	@Override
	public boolean checkAnswer(String userAnswer) {
		return answer.equalsIgnoreCase(userAnswer);
	}

}
